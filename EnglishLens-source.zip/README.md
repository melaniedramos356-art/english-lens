# 英语随手读 · English Lens

适用于 ARM64 Android 8.0+ 的英语拍照点读工具。0.1.0 是个人试用版。

## 功能

- 系统相机拍照或系统文件选择器导入照片，无需相册全部访问权限。
- 拖动方框选择图片区域，使用随 APK 打包的 ML Kit 英文识别模型提取文字。
- 修改识别文字；点击“生成可点击单词”后点词查询。
- 整句/单词朗读、停止、慢速切换；使用手机已安装的英语 TTS 引擎。
- 经用户确认后，通过 HTTPS 请求 MyMemory 英中翻译。不需要 API Key，不自动收费。
- 内置 ECDICT 常见词条与词形索引约 9 万条，提供释义、音标、词形变化和英文定义。
- WordNet 近义词；编辑距离为 1 的形近词。

## 边界和网络条件

这不是完整 AI 辅导产品。尚无可靠的逐词语境判断、专门生成的中文用法讲解或完整例句库。词卡中“英文释义/用法”来自词典，收录范围有限；近义词跨不同义项，不能直接替换。形近词由拼写算法筛选，可能包含生僻词。

MyMemory 匿名免费服务通常限制为每天 5000 字符、每次最多 500 字节，额度由服务方执行，可能按出口 IP 共享。网络异常或额度不足时显示失败，不切换到付费服务。翻译供应商和 GitHub 在中国大陆网络的可访问性无法保证。本机接口请求成功不代表小米14网络已通过验证。

朗读质量依赖手机 TTS。缺少英语语音时，应用会引导打开设置。尚未在小米14真机测试；必须自行核对英文识别和中文翻译。

## 安装

下载项目提供的 `EnglishLens-0.1.0-test.apk`，传到手机后打开安装。它是调试签名测试包，无广告、无付费入口。仅从自己确认的仓库或交付文件下载；核对随包 SHA-256。不要忽略系统发现的具体安全问题。

## 隐私

图片在设备上解码、裁剪与识别，不由本应用上传。照片临时写入应用私有缓存；页面销毁时尝试删除，系统异常退出后可能保留缓存，可在系统应用设置清理。无账号、通讯录、定位、麦克风、全部相册读取需求，不自建行为统计。依赖的 Google ML Kit 可能收集其政策规定的设备和性能诊断数据，见 https://developers.google.com/ml-kit/terms 。

翻译前明确确认，仅发送输入框文字到 `api.mymemory.translated.net`。服务方同时能接收网络 IP，不适合敏感材料。可以点击“撤回联网授权”。TTS 可能由第三方引擎联网处理朗读文本，取决于手机所选引擎及设置。没有任何软件可以承诺绝对零漏洞或零风险。

## 构建

需要 JDK 17、Gradle 8.7、Android SDK Platform 35 和 Build Tools 35.0.0。无需收费模型密钥。

```sh
gradle assembleDebug testDebugUnitTest lintDebug
```

APK 路径为 `app/build/outputs/apk/debug/app-debug.apk`。

仓库包含 GitHub Actions：推送 main 或在 Actions 手动运行后，下载 `EnglishLens-APK` 构建产物。当前工作流不自动发布 Release，也不包含生产签名密钥；工作流生成的调试签名可能与本机签名不同，安装前可能需要卸载旧测试版。

## 数据与授权

- ECDICT: https://github.com/skywind3000/ECDICT ，MIT，完整声明见 `THIRD_PARTY_ECDICT_LICENSE.txt`。
- WordNet: Princeton WordNet，完整声明见 `THIRD_PARTY_WORDNET_LICENSE.txt`。
- 字典资产是压缩的 UTF-8 JSON Lines，已包含构建所需数据，不需要安装时下载词典。
- ML Kit、AndroidX 使用各自许可与条款。不得将依赖自动视为本项目许可的一部分。

## 验证范围

见 `VALIDATION.md`。编译和静态分析不等于真机测试。未完成前不宣称所有功能在大陆网络或小米14可用。
