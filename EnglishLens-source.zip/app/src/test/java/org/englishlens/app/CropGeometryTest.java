package org.englishlens.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class CropGeometryTest {
 @Test public void landscapeLetterboxing(){assertArrayEquals(new int[]{250,100,500,200},CropGeometry.map(100,90,200,130,50,70,250,170,1000,500));}
 @Test public void reverseDrag(){assertArrayEquals(new int[]{250,100,500,200},CropGeometry.map(200,130,100,90,50,70,250,170,1000,500));}
 @Test public void outOfBoundsClamps(){assertArrayEquals(new int[]{0,0,1000,500},CropGeometry.map(-20,-10,800,900,50,70,250,170,1000,500));}
 @Test public void bottomRightStaysInside(){assertArrayEquals(new int[]{999,499,1,1},CropGeometry.map(250,170,250,170,50,70,250,170,1000,500));}
 @Test(expected=IllegalArgumentException.class) public void emptyPreviewRejected(){CropGeometry.map(0,0,10,10,0,0,0,0,100,100);}
}
