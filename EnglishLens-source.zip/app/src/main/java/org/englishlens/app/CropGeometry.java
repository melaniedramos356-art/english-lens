package org.englishlens.app;
/** Maps a selection on a letterboxed preview to bounded bitmap pixel coordinates. */
public final class CropGeometry {
 private CropGeometry() {}
 public static int[] map(float l,float t,float r,float b,float imageL,float imageT,float imageR,float imageB,int width,int height) {
  if(width<1 || height<1 || imageR<=imageL || imageB<=imageT) throw new IllegalArgumentException("Invalid image dimensions");
  float left=Math.min(l,r),right=Math.max(l,r),top=Math.min(t,b),bottom=Math.max(t,b);
  int x=Math.max(0,Math.min(width-1,(int)Math.floor((left-imageL)/(imageR-imageL)*width)));
  int y=Math.max(0,Math.min(height-1,(int)Math.floor((top-imageT)/(imageB-imageT)*height)));
  int endX=Math.max(x+1,Math.min(width,(int)Math.ceil((right-imageL)/(imageR-imageL)*width)));
  int endY=Math.max(y+1,Math.min(height,(int)Math.ceil((bottom-imageT)/(imageB-imageT)*height)));
  return new int[]{x,y,endX-x,endY-y};
 }
}
