package org.englishlens.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.text.*;
import android.text.style.ClickableSpan;
import android.text.method.LinkMovementMethod;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.util.zip.GZIPInputStream;
import org.json.*;

public class MainActivity extends Activity {
 final ExecutorService io=Executors.newSingleThreadExecutor();
 final Map<String,JSONObject> dictionary=new HashMap<>();
 final Map<String,String> synonyms=new HashMap<>();
 final Map<String,String> translationCache=new HashMap<>();
 EditText input; TextView result,words,status; CropView crop; TextToSpeech tts;
 boolean ttsReady=false, dictionaryReady=false,closed=false; Uri cameraUri; Bitmap photo;
 int translationId=0, wordId=0; float speed=0.85f;
 static final int INK=Color.rgb(25,40,62), BLUE=Color.rgb(32,102,210);
 int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
 @Override public void onCreate(Bundle b){super.onCreate(b);if(b!=null&&b.getString("cameraUri")!=null)cameraUri=Uri.parse(b.getString("cameraUri"));
 getWindow().setStatusBarColor(INK); getWindow().setNavigationBarColor(INK);
 ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(22),dp(20),dp(24));root.setBackgroundColor(Color.rgb(245,248,253));scroll.addView(root);setContentView(scroll);scroll.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
 TextView title=label("英语随手读",28);root.addView(title);root.addView(label("拍一下，读懂眼前的英文",15));
 LinearLayout row=new LinearLayout(this);root.addView(row);button(row,"拍照",v->takePhoto());button(row,"相册",v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,11);});
 crop=new CropView();root.addView(crop,new LinearLayout.LayoutParams(-1,dp(270)));root.addView(label("在图片上拖动框选，再点击识别；不框选则识别整张图。",13));
 button(root,"识别选中区域",v->recognize());
 input=new EditText(this);input.setTextSize(19);input.setMinLines(3);input.setGravity(Gravity.TOP);input.setHint("也可以在这里输入或修改英文句子");input.setText(b==null?"She leaves home at seven.":b.getString("sentence","She leaves home at seven."));root.addView(input,new LinearLayout.LayoutParams(-1,-2));
 input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){translationId++;wordId++; result.setText("");words.setText("");}public void afterTextChanged(Editable e){}});
 LinearLayout actions=new LinearLayout(this);root.addView(actions);button(actions,"朗读",v->speak(input.getText().toString()));button(actions,"停止",v->{if(tts!=null)tts.stop();});button(actions,"慢速/正常",v->{speed=speed==0.85f?0.65f:0.85f;toast("语速："+speed);});
 button(root,"中文翻译 · 联网",v->confirmOnline(()->translate()));
 result=label("",18);root.addView(result);root.addView(label("点击下面的单词查看词卡",15));words=label("",21);words.setMovementMethod(LinkMovementMethod.getInstance());root.addView(words);
 button(root,"生成可点击单词",v->renderWords());
 status=label("正在加载词典…",13);root.addView(status);button(root,"撤回联网授权",v->{getPreferences(0).edit().remove("online").apply();toast("已撤回；下次翻译将重新询问");});button(root,"隐私与使用说明",v->new AlertDialog.Builder(this).setTitle("隐私与使用说明").setMessage("不要求账号，不接入广告或自建统计服务。拍照和文字识别在手机执行，照片仅写入应用临时目录。中文翻译经你确认后，把输入框中的文字通过 HTTPS 发往 MyMemory，服务方也会接收网络 IP；不要提交隐私内容。免费匿名翻译有每日额度，服务可能无法在中国大陆网络访问。朗读使用手机安装的语音引擎，其联网行为由该引擎决定。词典释义不是 AI 语境解释；形近词不等于近义词。0.1 测试版尚未经过小米14真机验证。页面销毁时尝试清理临时照片。Google ML Kit 可能按其隐私政策收集设备及性能诊断数据。").setPositiveButton("知道了",null).show());
 tts=new TextToSpeech(this,code->{if(closed)return;if(code==TextToSpeech.SUCCESS){int r=tts.setLanguage(Locale.US);ttsReady=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;} });
 io.execute(()->{try(BufferedReader r=new BufferedReader(new InputStreamReader(new GZIPInputStream(getAssets().open("dictionary.jsonl.gz")),"UTF-8"))){String s;while((s=r.readLine())!=null){JSONObject j=new JSONObject(s);dictionary.put(j.getString("word"),j);}try(BufferedReader sr=new BufferedReader(new InputStreamReader(new GZIPInputStream(getAssets().open("synonyms.jsonl.gz")),"UTF-8"))){String line;while((line=sr.readLine())!=null){JSONObject item=new JSONObject(line);synonyms.put(item.getString("word"),item.getJSONArray("synonyms").join(" / ").replace("\"",""));}}runOnUiThread(()->{dictionaryReady=true;status.setText("词典已就绪 · "+dictionary.size()+" 词条 · 图片不上传");});}catch(Exception e){runOnUiThread(()->status.setText("词典加载失败："+e.getMessage()));}});
 }
 TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(INK);t.setPadding(0,dp(7),0,dp(7));return t;}
 void button(LinearLayout parent,String text,View.OnClickListener l){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setOnClickListener(l);parent.addView(b);}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 void takePhoto(){try{File dir=new File(getCacheDir(),"photos");dir.mkdirs();File f=File.createTempFile("scan-",".jpg",dir);cameraUri=FileProvider.getUriForFile(this,getPackageName()+".files",f);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);i.setClipData(ClipData.newRawUri("photo",cameraUri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);startActivityForResult(i,10);}catch(Exception e){toast("无法打开相机："+e.getMessage());}}
 @Override protected void onActivityResult(int req,int code,Intent data){super.onActivityResult(req,code,data);if(code!=RESULT_OK)return;Uri uri=req==10?cameraUri:(data==null?null:data.getData());if(uri==null)return;io.execute(()->{try{
 BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;try(InputStream s=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(s,null,opts);}opts.inSampleSize=1;while(Math.max(opts.outWidth,opts.outHeight)/opts.inSampleSize>2400)opts.inSampleSize*=2;opts.inJustDecodeBounds=false;
 Bitmap bitmap;try(InputStream s=getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(s,null,opts);}if(bitmap==null)throw new IOException("无法解码图片");
 Matrix m=new Matrix();try(InputStream s=getContentResolver().openInputStream(uri)){ExifInterface ex=new ExifInterface(s);int o=ex.getAttributeInt(ExifInterface.TAG_ORIENTATION,1);if(o==2)m.setScale(-1,1);if(o==3)m.setRotate(180);if(o==4)m.setScale(1,-1);if(o==5){m.setRotate(90);m.postScale(-1,1);}if(o==6)m.setRotate(90);if(o==7){m.setRotate(270);m.postScale(-1,1);}if(o==8)m.setRotate(270);}
 Bitmap ready=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),m,true);runOnUiThread(()->{if(closed)return;photo=ready;crop.selection=null;crop.invalidate();status.setText("图片已载入，请拖动框选");});
 }catch(Exception e){runOnUiThread(()->toast("图片读取失败："+e.getMessage()));}});}
 void recognize(){if(photo==null){toast("请先拍照或选择图片");return;}Bitmap selected=crop.selectedBitmap();status.setText("正在识别…");var recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);recognizer.process(InputImage.fromBitmap(selected,0)).addOnSuccessListener(t->{if(closed)return;input.setText(t.getText());renderWords();status.setText(t.getText().isEmpty()?"未发现英文，请靠近、补光并重新拍摄":"识别完成，请核对英文后朗读或翻译");}).addOnFailureListener(e->{if(!closed)status.setText("识别失败："+e.getMessage());}).addOnCompleteListener(t->recognizer.close());}
 void renderWords(){String s=input.getText().toString();SpannableString span=new SpannableString(s);Matcher m=Pattern.compile("[A-Za-z]+(?:['’-][A-Za-z]+)*").matcher(s);while(m.find()){String w=m.group();span.setSpan(new ClickableSpan(){public void onClick(View v){showWord(w);}},m.start(),m.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}words.setText(span);}
 void speak(String s){if(!ttsReady){new AlertDialog.Builder(this).setTitle("缺少英语朗读引擎").setMessage("请在手机的文字转语音设置中安装支持英语的语音数据，再重新打开应用。朗读效果取决于手机语音引擎。").setPositiveButton("打开设置",(d,w)->{try{startActivity(new Intent("com.android.settings.TTS_SETTINGS"));}catch(Exception e){toast("请到系统设置搜索文字转语音");}}).setNegativeButton("取消",null).show();return;}tts.setSpeechRate(speed);tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"english");}
 void confirmOnline(Runnable task){if(getPreferences(0).getBoolean("online",false)){task.run();return;}new AlertDialog.Builder(this).setTitle("允许发送所选文字？").setMessage("翻译会把输入框中的文字发送给 MyMemory（境外服务），照片不会发送。对方可接收文字和网络 IP。不要输入个人或敏感信息。免费额度有限，大陆网络可能连接失败。").setPositiveButton("允许本机记住选择",(d,w)->{getPreferences(0).edit().putBoolean("online",true).apply();task.run();}).setNegativeButton("取消",null).show();}
 void translate(){String text=input.getText().toString().trim();if(text.isEmpty())return;if(text.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>500){toast("每次请框选较短句子（不超过500字节）");return;}if(translationCache.containsKey(text)){result.setText("中文参考翻译\n"+translationCache.get(text)+"\n来源：MyMemory（本次会话缓存）");return;}final int id=++translationId;result.setText("正在查询中文翻译…");io.execute(()->{try{JSONObject data=getJson("https://api.mymemory.translated.net/get?q="+URLEncoder.encode(text,"UTF-8")+"&langpair=en%7Czh-CN");if(data.optInt("responseStatus")!=200)throw new IOException(data.optString("responseDetails","服务暂不可用"));String translated=data.getJSONObject("responseData").getString("translatedText");runOnUiThread(()->{if(!closed&&id==translationId){String clean=Html.fromHtml(translated,Html.FROM_HTML_MODE_LEGACY).toString();translationCache.put(text,clean);result.setText("中文参考翻译\n"+clean+"\n\n来源：MyMemory；机器翻译请结合原文核对。");}});}catch(Exception e){runOnUiThread(()->{if(!closed&&id==translationId)result.setText("翻译未成功："+e.getMessage()+"\n请检查网络或稍后再试；没有产生费用。");});}});}
 JSONObject getJson(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setInstanceFollowRedirects(false);try{if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());try(InputStream s=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=s.read(b))!=-1){if(out.size()+n>1000000)throw new IOException("响应过大");out.write(b,0,n);}return new JSONObject(out.toString("UTF-8"));}}finally{c.disconnect();}}
 void showWord(String raw){if(!dictionaryReady){toast("词典仍在加载，请稍等");return;}final String w=raw.toLowerCase(Locale.US).replace('’','\'');JSONObject j=dictionary.get(w);StringBuilder text=new StringBuilder();if(j!=null){text.append("音标：/").append(j.optString("phonetic")).append("/\n\n常见释义（非语境判定）\n").append(j.optString("translation").replace("\\n","\n")).append("\n\n词形变化\n").append(j.optString("exchange","暂无收录")).append("\n\n英文释义/用法\n").append(j.optString("definition","暂无收录").replace("\\n","\n"));}else{text.append("暂无该词条。可检查识别结果，或尝试查询原形。\n");}
 text.append("\n\n形近词（拼写接近，不代表意思相近）\n");int n=0;for(String candidate:dictionary.keySet()){if(n>=8)break;if(!candidate.equals(w)&&Math.abs(candidate.length()-w.length())<=1&&distance(w,candidate)==1){text.append(candidate).append("  ");n++;}}if(n==0)text.append("暂无收录");text.append("\n\n近义词（WordNet，不同义项不能随意替换）\n").append(synonyms.getOrDefault(w,"暂无收录；可尝试原形")).append("\n\n句中含义：本测试版提供整句翻译与词典释义，尚不具备 AI 语境判断。\n\n词形标记：p过去式 / d过去分词 / i现在分词 / 3第三人称 / s复数 / r比较级 / t最高级 / 0原形。\n词典来源：ECDICT (MIT)");new AlertDialog.Builder(this).setTitle(raw).setMessage(text.toString()).setPositiveButton("听发音",(d,which)->speak(raw)).setNegativeButton("关闭",null).show();}
 static int distance(String a,String b){int[] prev=new int[b.length()+1];for(int j=0;j<prev.length;j++)prev[j]=j;for(int i=1;i<=a.length();i++){int[] next=new int[b.length()+1];next[0]=i;for(int j=1;j<=b.length();j++)next[j]=Math.min(Math.min(prev[j]+1,next[j-1]+1),prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));prev=next;}return prev[b.length()];}
 @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);if(cameraUri!=null)out.putString("cameraUri",cameraUri.toString());out.putString("sentence",input.getText().toString());}
 @Override protected void onDestroy(){closed=true;translationId++;io.shutdownNow();if(tts!=null){tts.stop();tts.shutdown();}File dir=new File(getCacheDir(),"photos");File[] files=dir.listFiles();if(isFinishing()&&files!=null)for(File f:files)f.delete();super.onDestroy();}
 class CropView extends View{RectF imageRect=new RectF(),selection;float sx,sy;Paint paint=new Paint(3);CropView(){super(MainActivity.this);setBackgroundColor(Color.rgb(225,233,243));}protected void onDraw(Canvas c){super.onDraw(c);if(photo==null){paint.setColor(INK);paint.setTextSize(dp(18));c.drawText("拍照 / 导入英文图片",dp(20),getHeight()/2f,paint);return;}float scale=Math.min(getWidth()/(float)photo.getWidth(),getHeight()/(float)photo.getHeight());float w=photo.getWidth()*scale,h=photo.getHeight()*scale;imageRect.set((getWidth()-w)/2,(getHeight()-h)/2,(getWidth()+w)/2,(getHeight()+h)/2);c.drawBitmap(photo,null,imageRect,paint);if(selection!=null){paint.setColor(0x332066D2);c.drawRect(selection,paint);paint.setColor(BLUE);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(3));c.drawRect(selection,paint);paint.setStyle(Paint.Style.FILL);}}
 public boolean onTouchEvent(android.view.MotionEvent e){if(photo==null)return true;float x=Math.max(imageRect.left,Math.min(imageRect.right,e.getX())),y=Math.max(imageRect.top,Math.min(imageRect.bottom,e.getY()));if(e.getAction()==0){getParent().requestDisallowInterceptTouchEvent(true);sx=x;sy=y;selection=new RectF(x,y,x,y);}else if(e.getAction()==1||e.getAction()==2){selection=new RectF(Math.min(sx,x),Math.min(sy,y),Math.max(sx,x),Math.max(sy,y));if(e.getAction()==1){getParent().requestDisallowInterceptTouchEvent(false);if(selection.width()<dp(8)||selection.height()<dp(8))selection=null;performClick();}}else if(e.getAction()==3){getParent().requestDisallowInterceptTouchEvent(false);}invalidate();return true;}
 @Override public boolean performClick(){super.performClick();return true;}
 Bitmap selectedBitmap(){if(selection==null||imageRect.width()==0)return photo;int[] region=CropGeometry.map(selection.left,selection.top,selection.right,selection.bottom,imageRect.left,imageRect.top,imageRect.right,imageRect.bottom,photo.getWidth(),photo.getHeight());return Bitmap.createBitmap(photo,region[0],region[1],region[2],region[3]);}}
}
